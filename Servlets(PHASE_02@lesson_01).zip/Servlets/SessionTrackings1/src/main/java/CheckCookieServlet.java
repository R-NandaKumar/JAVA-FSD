import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;


public class CheckCookieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();

        response.setContentType("text/html");
        response.getWriter().println("<html>");
        response.getWriter().println("<head><title>Cookie Check</title></head>");
        response.getWriter().println("<body>");

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("username")) {
                    response.getWriter().println("Welcome back, " + cookie.getValue() + "!");
                    response.getWriter().println("<br>");
                    response.getWriter().println("Session handled with a cookie.");
                    return;
                }
            }
        }

        response.getWriter().println("Session not handled with a cookie.");
        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }
}
