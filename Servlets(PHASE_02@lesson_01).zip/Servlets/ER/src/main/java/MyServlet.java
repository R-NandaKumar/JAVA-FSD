import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // JDBC database connection parameters
  

        Connection connection = null;

        try {
            // Initialize the JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish a connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "root123");

            if (connection != null) {
                out.println("<h2>JDBC Connection Initialized Successfully!</h2>");
            } else {
                out.println("<h2>Failed to Initialize JDBC Connection</h2>");
            }
        } catch (ClassNotFoundException | SQLException e) 
        {
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        } finally {
            try {
                // Close the database connection
                if (connection != null) {
                    connection.close();
                    out.println("<h2>JDBC Connection Closed Successfully!</h2>");
                }
            } catch (SQLException e) {
                out.println("<h2>Error Closing JDBC Connection: " + e.getMessage() + "</h2>");
            }
        }
    }
}
