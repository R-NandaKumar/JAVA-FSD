import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the value of the "requestType" parameter from the request.
        String requestType = request.getParameter("requestType");

        // Set the content type of the response.
        response.setContentType("text/html");

        // Get the response writer.
        PrintWriter out = response.getWriter();

        // Check if a filter was applied to this request.
        String filterStatus = (String) request.getAttribute("filterStatus");

        // Write the HTML response.
        out.println("<html>");
        out.println("<head><title>Request Handling</title></head>");
        out.println("<body>");
        out.println("<h1>Request Handling</h1>");
        out.println("<p>Request Type: " + requestType + "</p>");
        if (filterStatus != null) {
            out.println("<p>Filter Status: " + filterStatus + "</p>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}
