                                                     Phase-2 Practice Project: Assisted Practice

1 Write a program to demonstrate the differences between GET and POST using Servlet.

2 Configure a servlet in Eclipse IDE.

3 Write a program to demonstrate the concept of Generic Servlets.

4 Write a program to demonstrate the concept of Servlet Classes and Interfaces.

5 Write a program to demonstrate a Servlet Filter.

6 Write a program to demonstrate a Session Tracking using Cookies.

7 Write a program to demonstrate a Session Tracking using URL Rewrite.

8 Write a program to demonstrate Session Tracking using Hidden Form Fields.

9 Write a program to demonstrate Session Tracking using an HTTP Session.

10 Write a program to demonstrate Session Login and Logout.


                                                            Phase-2 Practice Project

                                                      1 Validation of the User Login.





                                               Phase-2 Practice Project: Assisted Practice

1 Demonstrate a project to set up JDBC environment.

2 Demonstrate a project to set up JDBC environment.(Unassisted Practice)

3 Demonstrate Connection, Statement, and ResultSet in JDBC.

4 Demonstrate stored procedures and exception handling in JDBC.

5 Demonstrate how to create, select, and drop a database in JDBC.

6 Demonstrate Insertion, Updation, and Deletion of Database Records using JDBC.


                                                            Phase-2 Practice Project

                                            1 Retrieving the Product Details Using the Product ID.






                                               Phase-2 Practice Project: Assisted Practice

1 Configure Hibernate in Eclipse IDE.

2 Configure Hibernate using XML in Eclipse IDE.

3 Configure Hibernate using Annotations in Eclipse IDE.

4 Demonstrate Hibernate logging by Log4j.

5 Demonstrate mapping List, Set, Bag, and Map in collection using XML file.

6 Demonstrate lazy collection in Hibernate.

7 Demonstrate component mapping in Hibernate.

8 Demonstrate integration of Hibernate with spring.



                                                             Phase-2 Practice Project

                                                    1 Adding a New Product in the Database



                                            

                                             Phase-2 Practice Project: Assisted Practice

1 Write a program to configure JSP with Eclipse and Creating a Simple JSP Page.

2 Write a program to demonstrate the function of JSP Implicit Objects.

3 Write a program to demonstrate the use of JSP Directives.

4 Write a program to demonstrate the use of JSP action tags.

5 Write a program to demonstrate session handling in JSP.


                                                         Phase-2 Practice Project

                                                     1 Product Details Portal.