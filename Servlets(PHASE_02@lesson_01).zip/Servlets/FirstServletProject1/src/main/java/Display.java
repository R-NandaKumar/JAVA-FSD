

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Display extends HttpServlet 
{
	public void service(HttpServletRequest req,HttpServletResponse res)
	{
		try 
		{
		//	res.sendRedirect("/FirstServletProject1/display.html");
			PrintWriter pw =res.getWriter();
			pw.println("<!DOCTYPE html>");
			pw.println("<html>");
			pw.println("<head>");
			pw.println("<title>First Servlet Program</title>");
			pw.println("</head>");
			pw.println("<body>");
			pw.println("<p>Second Servlet Program</p>");
			pw.println("</body>");
			pw.println("</html>");
			
		} 
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
	}

}
