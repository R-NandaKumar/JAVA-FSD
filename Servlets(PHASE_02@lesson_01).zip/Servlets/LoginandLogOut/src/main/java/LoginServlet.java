import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {
    private static final String VALID_USERNAME = "nanda";
    private static final String VALID_PASSWORD = "nanda123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username.equals(VALID_USERNAME) && password.equals(VALID_PASSWORD)) {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            response.sendRedirect("dashboardhtml.html");
        } else {
            response.sendRedirect("error.html");
        }
    }
}
