package com.Servlet.classes.interfaces;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlets")
public class Servlets extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        // You can perform initialization tasks here if needed.
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the value of the "name" parameter from the request.
        String name = request.getParameter("name");

        // Set the content type of the response.
        response.setContentType("text/html");

        // Get the response writer.
        PrintWriter out = response.getWriter();

        // Write the HTML response.
        out.println("<html>");
        out.println("<head><title>Servlet Response</title></head>");
        out.println("<body>");
        out.println("<h2>Hello, " + name + "!</h2>");
        out.println("</body>");
        out.println("</html>");
    }

    public void destroy() {
        // Cleanup resources here if needed.
    }
}
