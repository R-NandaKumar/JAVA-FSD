package GenericServlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the name from the form input
        String name = request.getParameter("name");
        
        // Set the content type of the response
        response.setContentType("text/html");
        
        // Create an HTML response
        response.getWriter().println("<html>");
        response.getWriter().println("<head><title>Name Display</title></head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h1>Hello, " + name + "!</h1>");
        response.getWriter().println("</body></html>");
    }
}
