package com.Access.Modifier.Package01;

 public class Protected 
{
	 protected String  DataMember="DataMember is Accesable in same class of  protected Modifier";
	protected void display() 
    { 
        System.out.println("Inside the Package 01 of Procted "); 
        System.out.println(DataMember);
    } 
}
