package com.Access.Modifier.Package01;

public class Public 
{
		public String w="Data member is also Accesable Anywhere";
		public void disp()
		{
			System.out.println("Public method  is Accesable anywhere");
			System.out.println(w);
		}
}
