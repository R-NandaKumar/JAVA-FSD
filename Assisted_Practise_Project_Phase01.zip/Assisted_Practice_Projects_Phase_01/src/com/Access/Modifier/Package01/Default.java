package com.Access.Modifier.Package01;

public class Default
{
	public void  display()
	{
		System.out.println("Inside the Default Package 01");
	}

}
