package com.Access.Modifier.Package02;
import com.Access.Modifier.Package01.*;
public class ProtectedApp extends Protected
{
	public static void main(String[] args) 
	{
		    ProtectedApp obj = new ProtectedApp(); 
		    	obj.display();
		    	
		    	
	}
}
