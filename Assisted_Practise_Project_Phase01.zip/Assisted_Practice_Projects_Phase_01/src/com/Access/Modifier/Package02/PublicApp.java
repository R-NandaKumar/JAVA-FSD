package com.Access.Modifier.Package02;

import com.Access.Modifier.Package01.Public;


public class PublicApp {

	public static void main(String[] args) {
		  Public p = new Public();
		  p.disp();

	}

}
