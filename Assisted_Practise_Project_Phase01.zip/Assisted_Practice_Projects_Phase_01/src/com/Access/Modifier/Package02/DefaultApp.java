package com.Access.Modifier.Package02;

import com.Access.Modifier.Package01.Default;

public class DefaultApp {

	public static void main(String[] args) 
	{
		Default df = new Default();
				df.display();
				
				

	}

}
